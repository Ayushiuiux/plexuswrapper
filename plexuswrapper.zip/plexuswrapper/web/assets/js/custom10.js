sushiContractAddr= '0x099bC21AbE3536Bc1ccB99C79B913B8118FAc0F8';




function toggleTo(whichToggle){


  var wrapContractABI=[{"inputs":[],"stateMutability":"payable","type":"constructor"},{"stateMutability":"payable","type":"fallback"},{"inputs":[],"name":"ETH_TOKEN_ADDRESS","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"WETH_TOKEN_ADDRESS","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"lpAddress","type":"address"},{"internalType":"address","name":"token1","type":"address"},{"internalType":"address","name":"token2","type":"address"}],"name":"addLPPair","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address payable","name":"destination","type":"address"}],"name":"adminEmergencyWithdrawTokens","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"newOwner","type":"address"}],"name":"changeOwner","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"changeRecpientIsOwner","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"fee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"sellToken","type":"address"},{"internalType":"address","name":"buyToken","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"getBestPath","outputs":[{"internalType":"address[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"token1","type":"address"},{"internalType":"address","name":"token2","type":"address"}],"name":"getLPTokenByPair","outputs":[{"internalType":"address","name":"lpAddr","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address[]","name":"theAddresses","type":"address[]"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"getPriceFromUniswap","outputs":[{"internalType":"uint256[]","name":"amounts1","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"},{"internalType":"address","name":"tokenAddress","type":"address"}],"name":"getUserTokenBalance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"}],"name":"lpTokenAddressToPairs","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"maxfee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"}],"name":"presetPaths","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"newFee","type":"uint256"}],"name":"setFee","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newMax","type":"uint256"}],"name":"setMaxFee","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"","type":"string"}],"name":"stablecoins","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"sourceToken","type":"address"},{"internalType":"address","name":"destinationToken","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"unwrap","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"bool","name":"changeRecpientIsOwnerBool","type":"bool"}],"name":"updateChangeRecipientBool","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"newOwner","type":"address"}],"name":"updateOwnerAddress","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sellToken","type":"address"},{"internalType":"address","name":"buyToken","type":"address"},{"internalType":"address[]","name":"newPath","type":"address[]"}],"name":"updatePresetPaths","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"coinName","type":"string"},{"internalType":"address","name":"newAddress","type":"address"}],"name":"updateStableCoinAddress","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newAddress","type":"address"}],"name":"updateUniswapExchange","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newAddress","type":"address"}],"name":"updateUniswapFactory","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sourceToken","type":"address"},{"internalType":"address[]","name":"destinationTokens","type":"address[]"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"wrap","outputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"payable","type":"function"}]


  currentPlatform=whichToggle;
  $('.exOptions').removeClass('active');
  $('.exOptions').removeClass('andUnder');

  if(whichToggle ==1){

    $('#contractLink').attr('href', 'https://etherscan.io/address/0x95DE267b94130B1AA6Dd664247433212B9a27286#code').html('0x95DE267b94130B1AA6Dd664247433212B9a27286');


    $('.exOptions:nth(0)').addClass('andUnder');
    beforeButton = $('.mainButton').html();
    $('.mainButton').html(beforeButton.replace("SUSHI", "UNI"));
    $('.exOptions:nth(1)').addClass('active');
    setTimeout(function(){
        wrapContract = new web3.eth.Contract(wrapContractABI, wrapContractAddr);
    },1000)


  }

  if(whichToggle ==2){
    $('#contractLink').attr('href', 'https://etherscan.io/address/0x099bC21AbE3536Bc1ccB99C79B913B8118FAc0F8#code').html('0x099bC21AbE3536Bc1ccB99C79B913B8118FAc0F8');

    $('.exOptions:nth(1)').addClass('andUnder');
    beforeButton = $('.mainButton').html();
    $('.mainButton').html(beforeButton.replace("UNI", "SUSHI"));
      $('.exOptions:nth(0)').addClass('active');
      setTimeout(function(){
          wrapContract = new web3.eth.Contract(wrapContractABI, sushiContractAddr);
      },1000)

  }
}

currentBestGas = 10000000000;
function getGasPrice(){
  $.ajax({
    url:'cloud/api/beta/gasprice.php',
    complete:function(transport){
      gResp = $.parseJSON(transport.responseText);
      currentBestGas = parseInt(gResp['data']['standard'])
    }
  })
}

getGasPrice()
