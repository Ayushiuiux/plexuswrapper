
function generateLP(){

  $('.mainButton').html("Beginning Conversion...")
  setTimeout(function(){
    if(currentPlatform == 1){
        $('.mainButton').html("Generate UNI LP Tokens")
    }
    else{
        $('.mainButton').html("Generate SUSHI LP Tokens")
    }

  }, 1500);
  getConversion();
  /*
  swal({
   title: "This next click will do it all",
   text: "Are you sure you want to generate ~$1,200 worth of UNI LP Tokens?",
   type: 'warning',
   padding: '2em'
 })

 */
}


function getConversion(){

  ethAmount = parseFloat($('#ethAmount').val());

  if(typeof selectedAccount == "undefined"){
    swal({
     title: "Please connect your wallet for complete functionality",
     text: "In order to use to use this LP token converter, you will need to be connected via MetaMask or another Ethereum wallet provider.",
     type: 'warning',
     padding: '2em'
   })

   return;
  }

setupContracts();

  if(typeof ethAmount <= 0){
    swal({
     title: "Please enter a valid number",
     text: "Please convert a minimum of $5 in ETH",
     type: 'warning',
     padding: '2em'
   })

   return;
  }


  $.ajax({
    url:"cloud/api/beta/getEthToUSD.php?amount="+ethAmount,
    complete:function(transport){

      amountResp = $.parseJSON(transport.responseText);


      baseNum = parseFloat(amountResp['data']);

      if(baseNum <4){
        swal({
         title: "That's a such a small amount",
         text: "Please convert a minimum of $5 in ETH",
         type: 'warning',
         padding: '2em'
       })
         return;
      }


      displayAmount = amountResp['data'].toFixed(2)

      console.log(displayAmount);
      $('#estimatedConv').html(displayAmount)
      token1Name = $('.tokendown1').dropdown('get value');
      token2Name = $('.tokendown2').dropdown('get value');


      if(token1Name == token2Name){
        swal({
         title: "Please select two different tokens",
         text: "There is no such thing as an "+token1Name+"-"+token2Name+" LP Token",
         type: 'warning',
         padding: '2em'
       })
         return;
      }

      swal({
       title: "Converting to ~ $"+displayAmount+"\n of\n "+token1Name+"-"+token2Name+" LP tokens",
       text: "Please confirm the details of your transaction.",
       type: 'warning',
       padding: '2em'
     })
setTimeout(function(){
  activateOkayListen()
},1000)


    }
  })

}


function activateOkayListen(){
  getGasPrice()
  $('.swal2-confirm').on('click', function(){
    $('.swal2-container').off('click')
    $('.swal2-confirm').off('click')
      commenseWrap()
  })

  $('.swal2-container').on('click', function(){
    $('.swal2-container').off('click')
    $('.swal2-confirm').off('click')

  })


  //commenseWrap();
}
