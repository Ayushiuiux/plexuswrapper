if(window.location.href.indexOf('plexus') ==-1){
  window.location = "https://www.plexus.money";
}


function swapWraps(whichOne){
$('#topAccordion li').removeClass('active')
changeTo(1)

if(whichOne ==1){
if(currentDirection ==2){
  return;
}
$("#toContainer").after($("#fromContainer"));
//$("#arrowSection").before($("#fromContainer"));
$("#arrowSection").before($("#toContainer"));
$('.howMuchLP').show()
$('#ethAmount').hide()
$('.ethLabel').css({'width':'320px'}).removeClass('tag').attr('data-content', 'You will convert the LP tokens to ETH')
$('.mainButton').html('Unwrap LP Tokens & Sell Underlying')
getPairLPBalance()
$('.mainButton').attr('onclick','unwrapThis()')
}



else{
  if(currentDirection ==1){
    return;
  }
  $("#toContainer").before($("#fromContainer"));
  $("#arrowSection").after($("#toContainer"));
  $('#ethAmount').show()
  $('.ethLabel').css({'width':'120px'}).addClass('tag').attr('data-content', 'You can convert from this amount of ETH to LP tokens you select below')
$('.howMuchLP').hide()
if(currentPlatform ==1){
  $('.mainButton').html('Generate UNI LP Tokens')
}
else{
  $('.mainButton').html('Generate SUSHI LP Tokens')
}

$('.mainButton').attr('onclick','generateLP()')
}

if(currentDirection == 1){
  currentDirection =2;
}
else{
  currentDirection=1;
}


}

currentDirection = 1;
$('#arrowSection').css({ cursor: 'pointer' });
$('#arrowSection').on('click', function(){
  swapWraps(currentDirection);

})

currentApproving={};
currentTokenLPBalance = 0;
isApproved= 0;
async function getPairLPBalance(){
  $('.mainButton').html('...')
  $(".maxButtonLP").attr("onclick", "getPairLPBalance()");
  $(".inputYieldMax").css({width:"155px"})
  $('.maxButtonLP').html("Max");
  setupContracts()

t1 = tokenAddrs[$('.tokendown1').dropdown('get value')];
t2 = tokenAddrs[$('.tokendown2').dropdown('get value')]

if(t1 == t2){
  $('.mainButton').html('Invalid Pair').attr("onclick", "")
  return;
}
  var result = await  wrapContract.methods.getLPTokenByPair(t1, t2).call();


currentLPToken = result;

var aContract = new web3.eth.Contract(erc20ABI, currentLPToken);

isApproved = await  aContract.methods.allowance(selectedAccount, wrapContractAddr).call();

if(isApproved==0 && typeof currentApproving[currentLPToken] == "undefined"){
//  $(".maxButtonLP").attr("onclick", "approveIt(\'"+ currentLPToken+"\')")
//  $('.maxButtonLP').html("Approve");
$('.mainButton').attr('onclick',"approveIt(\'"+ currentLPToken+"\')").html("Approve This LP Token")
  //$(".inputYieldMax").css({width:"110px"})

}
else{
  $('.mainButton').html('Unwrap LP Tokens & Sell Underlying')

  $('.mainButton').attr('onclick','unwrapThis()')
}

var result = await  aContract.methods.balanceOf(selectedAccount).call();
//  console.log(result)

//currentTokenLPBalance = (result/1000000000000000000).toFixed(3);
currentTokenLPBalance = toFixed(result/1000000000000000000, 10).toFixed(11);

$('.inputYieldMax').val(currentTokenLPBalance);

}

currentApprovingToken = ""
function approveIt(whichToken){
currentApprovingToken  = whichToken;
  var aContract = new web3.eth.Contract(erc20ABI, whichToken);
  var tx = aContract.methods.approve(wrapContractAddr, '1000000000000000000000000000000000').send({

    'from': selectedAccount,

    //'gas':190000,
    'gasPrice':currentBestGas



  }, function(error, data){


if(!error){
  currentApproving[currentApprovingToken] = true;
  showNotif("Token Approval Request Submitted to the Blockchain!", "You will need to wait a little while for a confirmation. Then you will be able to unwrap this token. You can also look at your pending transactions on MetaMask to speed this up. ");
getPairLPBalance();
 }
    console.log(error);
    console.log(data)







  })
}


function toFixed(num, fixed) {
    fixed = fixed || 0;
    fixed = Math.pow(10, fixed);
    return Math.floor(num * fixed) / fixed;
}
Number.prototype.toFixedSpecial = function(n) {
  var str = this.toFixed(n);
  if (str.indexOf('e+') === -1)
    return str;

  // if number is in scientific notation, pick (b)ase and (p)ower
  str = str.replace('.', '').split('e+').reduce(function(p, b) {
    return p + Array(b - p.length + 2).join(0);
  });

  if (n > 0)
    str += '.' + Array(n + 1).join(0);

  return str;
};


async function unwrapThis(){

    theAmount = parseFloat($('.inputYieldMax').val());

    theFormattedAmount = parseInt((theAmount * (Math.pow(10, 18))))

    theFormattedAmount = theFormattedAmount.toFixedSpecial(0);


    console.log(theFormattedAmount);
    token1 = tokenAddrs[$('.tokendown1').dropdown('get value')];
    token2 = tokenAddrs[$('.tokendown2').dropdown('get value')];

    console.log(token1)
    console.log(token2)

    token1Name = $('.tokendown1').dropdown('get value');
    token2Name = $('.tokendown2').dropdown('get value');

    lpTokenAddress =  await  wrapContract.methods.getLPTokenByPair(token1, token2).call();

    tx1 = wrapContract.methods.unwrap(lpTokenAddress, '0x0000000000000000000000000000000000000000', theFormattedAmount.toString()).send({

      'from': selectedAccount,

      'gas':determineGasLimit1(token1Name, token2Name),
      'gasPrice':currentBestGas
    //  value:theFormattedAmount.toString()


    }, function(error, data){

      console.log(error);
      console.log(data)
      if(!error){
      showNotif("Your LP unwrap transaction has been submitted to the blockchain", "In a few moments, once there is a confirmation on the blockchain, you will get a MetaMask notification. You can also check your Metamask to raise the gas price and speed up your transaction if you would like.");


      }


    })
}
if(6==7){
    window.location = "https://www.plexus.money";
}

if(6==7){
    window.location = "https://www.plexus.money";
}

function checkLPChange(){
  if(currentDirection!=1){
    getPairLPBalance();
  }
}
