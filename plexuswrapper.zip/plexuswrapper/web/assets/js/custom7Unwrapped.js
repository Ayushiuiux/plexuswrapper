currentPlatform = 1; //uniswap


function setupContracts(){

wrapContractABI=[{"inputs":[],"stateMutability":"payable","type":"constructor"},{"stateMutability":"payable","type":"fallback"},{"inputs":[],"name":"ETH_TOKEN_ADDRESS","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"WETH_TOKEN_ADDRESS","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"lpAddress","type":"address"},{"internalType":"address","name":"token1","type":"address"},{"internalType":"address","name":"token2","type":"address"}],"name":"addLPPair","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address payable","name":"destination","type":"address"}],"name":"adminEmergencyWithdrawTokens","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"newOwner","type":"address"}],"name":"changeOwner","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"changeRecpientIsOwner","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"fee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"sellToken","type":"address"},{"internalType":"address","name":"buyToken","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"getBestPath","outputs":[{"internalType":"address[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"token1","type":"address"},{"internalType":"address","name":"token2","type":"address"}],"name":"getLPTokenByPair","outputs":[{"internalType":"address","name":"lpAddr","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address[]","name":"theAddresses","type":"address[]"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"getPriceFromUniswap","outputs":[{"internalType":"uint256[]","name":"amounts1","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"},{"internalType":"address","name":"tokenAddress","type":"address"}],"name":"getUserTokenBalance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"}],"name":"lpTokenAddressToPairs","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"maxfee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"}],"name":"presetPaths","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"newFee","type":"uint256"}],"name":"setFee","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newMax","type":"uint256"}],"name":"setMaxFee","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"","type":"string"}],"name":"stablecoins","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"sourceToken","type":"address"},{"internalType":"address","name":"destinationToken","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"unwrap","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"bool","name":"changeRecpientIsOwnerBool","type":"bool"}],"name":"updateChangeRecipientBool","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"newOwner","type":"address"}],"name":"updateOwnerAddress","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sellToken","type":"address"},{"internalType":"address","name":"buyToken","type":"address"},{"internalType":"address[]","name":"newPath","type":"address[]"}],"name":"updatePresetPaths","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"coinName","type":"string"},{"internalType":"address","name":"newAddress","type":"address"}],"name":"updateStableCoinAddress","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newAddress","type":"address"}],"name":"updateUniswapExchange","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newAddress","type":"address"}],"name":"updateUniswapFactory","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sourceToken","type":"address"},{"internalType":"address[]","name":"destinationTokens","type":"address[]"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"wrap","outputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"payable","type":"function"}]

  if(currentPlatform ==1){
      wrapContractAddr = '0x95DE267b94130B1AA6Dd664247433212B9a27286';
  }
  else{
    wrapContractAddr = '0x099bC21AbE3536Bc1ccB99C79B913B8118FAc0F8'
  }


//old: 0x5C1009674Ae77CB9D92E47d1Bd4C10A8eaF5AdF0
wrapContract = new web3.eth.Contract(wrapContractABI, wrapContractAddr);

getGasPrice()
}


function isStable(tokenName){
  if(tokenName == "DAI" || tokenName == "ETH" || tokenName == "USDT" || tokenName == "USDC" || tokenName == "UST"){
    return true;
  }
  else{
    return false;
  }
}

function determineGasLimit(token1N, token2N){
  baseLimit = 750000;
  if(!isStable(token1N)){
    baseLimit = baseLimit + 400000;
  }

  if(!isStable(token2N)){
    baseLimit = baseLimit + 400000;
  }

  return baseLimit;
}

function determineGasLimit1(token1N, token2N){
  baseLimit = 700000;
  if(!isStable(token1N)){
    baseLimit = baseLimit + 250000;
  }

  if(!isStable(token2N)){
    baseLimit = baseLimit + 250000;
  }

  return baseLimit;
}

async function commenseWrap(){


  ethAmount = parseFloat($('#ethAmount').val());

  theFormattedAmount = ethAmount * (Math.pow(10, 18));
  console.log(theFormattedAmount);
  token1 = tokenAddrs[$('.tokendown1').dropdown('get value')];
  token2 = tokenAddrs[$('.tokendown2').dropdown('get value')];

  console.log(token1)
  console.log(token2)

  lpTokenAddress =  await  wrapContract.methods.getLPTokenByPair(token1, token2).call();

  if(lpTokenAddress == '0x0000000000000000000000000000000000000000'){
    showNotif("This is an invalid pair on Uniswap", );
    swal({
     title: "This is an invalid pair on Uniswap",
     text: "There has not yet been liquidity provided to this pair. You can provide liquidity on Uniswap or by interacting directly with this smart contract (experimental)",
      type: 'warning',
     padding: '2em'
   })



    return;
  }

  token1Name = $('.tokendown1').dropdown('get value');
  token2Name = $('.tokendown2').dropdown('get value');

  lpSet= [token1, token2];

  tx1 = wrapContract.methods.wrap('0x0000000000000000000000000000000000000000', lpSet, 1).send({

    'from': selectedAccount,

    'gas':determineGasLimit(token1Name, token2Name),
    'gasPrice':currentBestGas,
    value:theFormattedAmount.toString()


  }, function(error, data){

    console.log(error);
    console.log(data)
    if(!error){
    showNotif("Your LP creation transaction has been submitted to the blockchain", "In a few moments, once there is a confirmation on the blockchain, you will get a MetaMask notification. You can also check your Metamask to raise the gas price and speed up your transaction if you would like.");


    }


  })

}
