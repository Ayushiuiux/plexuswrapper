mainContractAddr='0x3569DF3cAb35120085A33d00cC299f774E5Ed08C';
tokenAddrs = {
  "DAI":"0x6B175474E89094C44Da98b954EedeAC495271d0F",
  "WETH":"0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
  "ETH": "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
  "USDC":"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
  "PLEX":"0x0391D2021f89DC339F60Fff84546EA23E337750f",
  "PLEXUSDCLP":"0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984",
  "PLEXLP":"0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984",
  "CRV":"0xD533a949740bb3306d119CC777fa900bA034cd52",
  "USDT":"0xdAC17F958D2ee523a2206206994597C13D831ec7",
  "SUSD":"0x57Ab1ec28D129707052df4dF418D58a2D46d5f51",
  "PICKLE":"0x429881672B9AE42b8EbA0E26cD9C73711b891Ca5",
  "FARM":"0xa0246c9032bC3A600820415aE600c6388619A14D",
  "TUSD":"0x0000000000085d4780B73119b644AE5ecd22b376",



  "AAVE":"0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9",
  "AMPL":"0xD46bA6D942050d489DBd938a2C909A5d5039A161",
  "MPH":"0x8888801aF4d980682e47f1A9036e589479e835C5",
  "DPI":"0x1494CA1F11D487c2bBe4543E90080AeBa4BA3C2b",
  "UNI":"0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984",
  "BOND":"0x0391D2021f89DC339F60Fff84546EA23E337750f",




  "AMP":"0xfF20817765cB7f73d4bde2e66e067E58D11095C2",
  "ANT":"0x960b236A07cf122663c4303350609A66A7B288C0",
  "BAL":"0xba100000625a3754423978a60c9317c58a424e3D",
  "BAND":"0xBA11D00c5f74255f56a5E366F4F77f5A186d7f55",
  "BNT":"0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C",
  "COMP":"0xc00e94Cb662C3520282E6f5717214004A7f26888",
  "CVC":"0x41e5560054824eA6B0732E656E3Ad64E20e94E45",
  "DNT":"0x0AbdAce70D3790235af448C88547603b945604ea",
  "GNO":"0x6810e776880C02933D47DB1b9fc05908e5386b96",
  "GRT":"0xc944E90C64B2c07662A292be6244BDf05Cda44a7",
  "KEEP":"0x85Eee30c52B0b379b046Fb0F85F4f3Dc3009aFEC",
  "KNC":"0xdd974D5C2e2928deA5F71b9825b8b646686BD200",
  "LINK":"0x514910771AF9Ca656af840dff83E8264EcF986CA",
  "LOOM":"0xA4e8C3Ec456107eA67d3075bF9e3DF3A75823DB0",
  "LRC":"0xBBbbCA6A901c926F240b89EacB641d8Aec7AEafD",
  "MANA":"0x0F5D2fB29fb7d3CFeE444a200298f468908cC942",
  "MKR":"0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2",
  "MLN":"0xec67005c4E498Ec7f55E092bd1d35cbC47C91892",
  "NMR":"0x1776e1F26f98b1A5dF9cD347953a26dd3Cb46671",
  "NU":"0x4fE83213D56308330EC302a8BD641f1d0113A4Cc",
  "REN":"0x408e41876cCCDC0F92210600ef50372656052a38",
  "REPV2":"0x221657776846890989a759BA2973e427DfF5C9bB",
  "SNX":"0xC011a73ee8576Fb46F5E1c5751cA3B9Fe0af2a6F",
  "STORJ":"0xB64ef51C888972c908CFacf59B47C1AfBC0Ab8aC",
  "TBTC":"0x8dAEBADE922dF735c38C80C7eBD708Af50815fAa",
  "UMA":"0x04Fa0d235C4abf4BcF4787aF4CF447DE572eF828",
  "YFI":"0x0bc529c00C6401aEF6D220BE8C6Ea1667F6Ad93e",
  "ZRX":"0xE41d2489571d322189246DaFA5ebDe1F4699F498",

  "MIR":"0x09a3EcAFa817268f77BE1283176B946C4ff2E608",
  "UST":"0xa47c8bf37f92aBed4A126BDA807A7b7498661acD",



  "MTSLA":"0x21cA39943E91d704678F5D00b6616650F066fD63",
  "MBABA":"0x56aA298a19C93c6801FDde870fA63EF75Cc0aF72",
  "MNFLX":"0xC8d674114bac90148d11D3C1d33C61835a0F9DCD",
  "MTWTR":"0xEdb0414627E6f1e3F082DE65cD4F9C693D78CCA9",
  "MVIXY":"0xf72FCd9DCF0190923Fadd44811E240Ef4533fc86",

  "SRM":"0x476c5E26a75bd202a9683ffD34359C0CC15be0fF",
  "XSUSHI":"0x8798249c2E607446EfB7Ad49eC89dD1865Ff4272",
  "CREAM":"0x2ba592F78dB6436527729929AAf6c908497cB200",
  "MEME":"0xD5525D397898e5502075Ea5E830d8914f6F0affe",
  "WNXM":"0x0d438F3b5175Bebc262bF23753C1E53d03432bDE",
  "CORE":"0x62359Ed7505Efc61FF1D56fEF82158CcaffA23D7",
  "HEGIC":"0x584bC13c7D411c00c01A62e8019472dE68768430",
  "GHST":"0x3F382DbD960E3a9bbCeaE22651E88158d2791550",
  "YAM":"0x0AaCfbeC6a24756c20D41914F2caba817C0d8521",
  "DOUGH":"0xad32A8e6220741182940c5aBF610bDE99E737b2D",
  "STAKE":"0x0Ae055097C6d159879521C384F1D2123D1f195e6",
  "KP3R":"0x1cEB5cB57C4D4E2b2433641b95Dd330A33185A44",
  "AXS":"0xF5D669627376EBd411E34b98F19C868c8ABA5ADA",
  "ZLOT":"0xA8e7AD77C60eE6f30BaC54E2E7c0617Bd7B5A03E",
  "YETI":"0xb4bebD34f6DaaFd808f73De0d10235a92Fbb6c3D",
  "BADGER":"0x3472A5A71965499acd81997a54BBA8D852C6E53d",
  "MBBASED":"0x26cF82e4aE43D31eA51e72B663d26e26a75AF729",
  "ALPHA":"0x26cF82e4aE43D31eA51e72B663d26e26a75AF729",
  "COMBO":"0xfFffFffF2ba8F66D4e51811C5190992176930278",
  "SPANK":"0x42d6622deCe394b54999Fbd73D108123806f6a18",
  "OPIUM":"0x888888888889C00c67689029D7856AAC1065eC11",
  "MBTC":"0x945Facb997494CC2570096c74b5F66A3507330a1",
  "PREMIA":"0x6399C842dD2bE3dE30BF99Bc7D1bBF6Fa3650E70",
  "TORN":"0x77777FeDdddFfC19Ff86DB637967013e6C6A116C",
  "YLD":"0xDcB01cc464238396E213a6fDd933E36796eAfF9f",
  "RGT":"0xD291E7a03283640FDc51b121aC401383A46cC623",
  "MTA":"0xa3BeD4E1c75D00fa6f4E5E6922DB7261B5E9AcD2",
  "LDO":"0x5A98FcBEA516Cf06857215779Fd812CA3beF1B32",
  "1INCH":"0x111111111117dC0aa78b770fA6A738034120C302",
  "OUSD":"0x2A8e1E676Ec238d8A992307B495b45B3fEAa5e86",
  "RUNE":"0x3155BA85D5F96b2d030a4966AF206230e46849cb",
  "ZHEGIC":"0x837010619aeb2AE24141605aFC8f66577f6fb2e7",
  "SUSHI":"0x6B3595068778DD592e39A122f4f5a5cF09C90fE2"










}

mainContractABI=[{"inputs":[],"stateMutability":"payable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"address","name":"token","type":"address"}],"name":"Deposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"address","name":"token","type":"address"}],"name":"Withdrawal","type":"event"},{"stateMutability":"payable","type":"fallback"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address payable","name":"destination","type":"address"}],"name":"adminWithdrawTokens","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"tokenAddress","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"deposit","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"tokenAddress","type":"address"}],"name":"getAPY","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"tokenAddress","type":"address"},{"internalType":"address","name":"userAddress","type":"address"}],"name":"getAmountStakedByUser","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getComposition","outputs":[{"internalType":"uint256[]","name":"compAmounts","type":"uint256[]"},{"internalType":"address[]","name":"compTokens","type":"address[]"},{"internalType":"string[]","name":"compNames","type":"string[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getStakableTokens","outputs":[{"internalType":"address[6]","name":"","type":"address[6]"},{"internalType":"string[6]","name":"","type":"string[6]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getThisTokenPrice","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getTotalValueLockedAggregated","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getTotalValueLockedInternal","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"tokenAddress","type":"address"}],"name":"getTotalValueLockedInternalByToken","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"}],"name":"getUserCurrentReward","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"}],"name":"getUserPotentialReward","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"userAddress","type":"address"},{"internalType":"address","name":"tokenAddress","type":"address"}],"name":"getUserWalletBalance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"kill","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"populateData","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"timeLeftInEpoch","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"tokenAddress","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"withdraw","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"payable","type":"function"}]



erc20ABI =[{"inputs":[{"internalType":"uint256","name":"chainId_","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"src","type":"address"},{"indexed":true,"internalType":"address","name":"guy","type":"address"},{"indexed":false,"internalType":"uint256","name":"wad","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":true,"inputs":[{"indexed":true,"internalType":"bytes4","name":"sig","type":"bytes4"},{"indexed":true,"internalType":"address","name":"usr","type":"address"},{"indexed":true,"internalType":"bytes32","name":"arg1","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"arg2","type":"bytes32"},{"indexed":false,"internalType":"bytes","name":"data","type":"bytes"}],"name":"LogNote","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"src","type":"address"},{"indexed":true,"internalType":"address","name":"dst","type":"address"},{"indexed":false,"internalType":"uint256","name":"wad","type":"uint256"}],"name":"Transfer","type":"event"},{"constant":true,"inputs":[],"name":"DOMAIN_SEPARATOR","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"PERMIT_TYPEHASH","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"usr","type":"address"},{"internalType":"uint256","name":"wad","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"usr","type":"address"},{"internalType":"uint256","name":"wad","type":"uint256"}],"name":"burn","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"guy","type":"address"}],"name":"deny","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"usr","type":"address"},{"internalType":"uint256","name":"wad","type":"uint256"}],"name":"mint","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"src","type":"address"},{"internalType":"address","name":"dst","type":"address"},{"internalType":"uint256","name":"wad","type":"uint256"}],"name":"move","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"nonces","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"holder","type":"address"},{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"nonce","type":"uint256"},{"internalType":"uint256","name":"expiry","type":"uint256"},{"internalType":"bool","name":"allowed","type":"bool"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permit","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"usr","type":"address"},{"internalType":"uint256","name":"wad","type":"uint256"}],"name":"pull","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"usr","type":"address"},{"internalType":"uint256","name":"wad","type":"uint256"}],"name":"push","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"guy","type":"address"}],"name":"rely","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"dst","type":"address"},{"internalType":"uint256","name":"wad","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"src","type":"address"},{"internalType":"address","name":"dst","type":"address"},{"internalType":"uint256","name":"wad","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"version","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"wards","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"}];




//read template:
//  var result = await  readerContract.methods.processSet(tokens1, tokens2, amounts, whichExchanges, types, contractAddresses, flashLoanEnabled, flashLoanContract, flashLoanRepaymentAddress).call();
//  console.log(result)



//write template:
/*
var tx = theContract.methods.processSet(tokens1, tokens2, amounts, whichExchanges, types, contractAddresses, flashLoanEnabled, flashLoanContract, flashLoanRepaymentAddress).send({

  'from': selectedAccount,

  //'gas':190000,
  //'gasPrice':gasPriceGeneratedFast,
  value:0


}, function(error, data){

  console.log(error);
  console.log(data)




})




*/
