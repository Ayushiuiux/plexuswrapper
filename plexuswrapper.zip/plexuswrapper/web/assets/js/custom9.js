windowInfo = window.location.href;

if(windowInfo.indexOf('UNISWAP:') != -1){
  toggleTo(1);
  baseData = windowInfo.split('UNISWAP:')[1];
  tSymbols = baseData.split('/');
  tSymbol1 = tSymbols[0]
  tSymbol2 = tSymbols[1].split('&')[0];
  $('.tokendown1').dropdown('set selected', tSymbol1);
   $('.tokendown2').dropdown('set selected', tSymbol2);

}

if(windowInfo.indexOf('SUSHI:') != -1){

  toggleTo(2);
  baseData = windowInfo.split('SUSHI:')[1];
  tSymbols = baseData.split('/');
  tSymbol1 = tSymbols[0]
  tSymbol2 = tSymbols[1].split('&')[0];
  $('.tokendown1').dropdown('set selected', tSymbol1);
   $('.tokendown2').dropdown('set selected', tSymbol2);

}
