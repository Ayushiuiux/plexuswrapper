function changeTo(whichTo){



  if(whichTo != 5){
      $('#topOne').hide()
      $("html, body").animate({ scrollTop: $('#actionArea').offset().top }, 700);
  }
  else{
    $('#topOne').show()
  }

/*
  if(whichTo ==1 || whichTo==2){
  $('#overlay1').show()
  }
  else{
    $('#overlay1').hide()
  }

  */
$('.otherScreens').hide()
  $('#topAccordion li').removeClass('active')
      $('.bigSec').hide()
            $('.bigSec:nth('+(whichTo-1)+')').show()
            //  $('#topAccordion li:nth('+(whichTo-1)+')').addClass('active')
/*  switch(whichTo){

    case 1:
      $('#topAccordion li:nth(1)').addClass('active')

    break;


    case 2:
      $('#topAccordion li:nth(2)').addClass('active')

    break;


    case 3:
  $('#topAccordion li:nth(0)').addClass('active')

    break;




    case 4:
  $('#topAccordion li:nth(4)').addClass('active')

    break;


    case 5:
  $('#topAccordion li:nth(3)').addClass('active')

    break;

  }
*/

getAllContractData();


if(typeof selectedAccount == "undefined"){
  swal({
   title: "Please connect your wallet for complete functionality",
   text: "In order to use to use this LP token converter, you will need to be connected via MetaMask or another Ethereum wallet provider.",
   type: 'warning',
   padding: '2em'
 })
}


}



function activateDropEffects(){

$('.dropdown-menu .dropdown-item:contains(Borrow)').on('click', function(){

    changeTo(2)
})


$('.dropdown-menu .dropdown-item:contains(Deposit)').on('click', function(){
  changeTo(1)
})

$('.dropdown-menu .dropdown-item:contains(Stake)').on('click', function(){
  changeTo(3)
})

$('.dropdown-menu .dropdown-item:contains(Unstake)').on('click', function(){
  changeTo(5)
})


$('.dropdown-menu .dropdown-item:contains(Aave + Plex)').on('click', function(){
  $($(this).parent().parent()).find('button').html('Aave + Plex <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>')
  $($(this).parent()).find('.defaultLocation').hide()
})

$('.dropdown-menu .dropdown-item:contains(Harvest + Plex)').on('click', function(){
  $($(this).parent().parent()).find('button').html('Harvest + Plex <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>')
  $($(this).parent()).find('.defaultLocation').show()
})

$('.dropdown-menu .dropdown-item:contains(Pickle + Plex)').on('click', function(){
  $($(this).parent().parent()).find('button').html('Pickle + Plex <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>')
    $($(this).parent()).find('.defaultLocation').show()
})

$('.dropdown-menu .dropdown-item:contains(All + Plex)').on('click', function(){
  $($(this).parent().parent()).find('button').html('All + Plex <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>')
    $($(this).parent()).find('.defaultLocation').show()
})





$('.maxButton').on('click', function(){
  var amountHas =   parseFloat($($(this).parent().parent().parent()).find('.tokenBalanceClass').html());
  $($(this).parent()).find('input').val(amountHas)
    if($($(this).parent()).find('button').length <2){

          thisSymbol = $($(this).parent().parent().parent()).find('.tokenBalanceClass').html().split(" ")[1];

        if($(this).parents('.unstakeSec').length ==0){
          $($(this).parent()).append('<button class="btn btn-outline-success goButton  goBut'+thisSymbol+'"  style="height:48px; margin-top:-7px">Earn</button>')

          determineButtonText(thisSymbol);
        }

        else{
          $($(this).parent()).append('<button class="btn btn-outline-success goButton"  style="height:48px; margin-top:-7px">Go</button>')

        }
  }
})

$('.inputYield').on('focus', function(){

  if($($(this).parent()).find('button').length <2){
  $($(this).parent()).find('input').val('').attr('placeholder','0.00')
  thisSymbol = $($(this).parent().parent().parent()).find('.tokenBalanceClass').html().split(" ")[1];

if($(this).parents('.unstakeSec').length ==0){
  $($(this).parent()).append('<button class="btn btn-outline-success goButton  goBut'+thisSymbol+'"  style="height:48px; margin-top:-7px">Earn</button>')

  determineButtonText(thisSymbol);
}
else{
  $($(this).parent()).append('<button class="btn btn-outline-success goButton"  style="height:48px; margin-top:-7px">Go</button>')

}

  }
})



$('.inputYield').on('blur', function(){
if($($(this).parent()).find('input').val() == "" || parseFloat($($(this).parent()).find('input').val()) == 0){
    $($(this).parent()).find('.goButton').remove()
}
})


async function  determineButtonText(whichButton){
  thisTokAddr = tokenAddrs[whichButton];
  thisTokenSym = whichButton;
  theButton = '.goBut'+whichButton;

  var aContract = new web3.eth.Contract(erc20ABI, thisTokAddr);

    var approval1 = await  aContract.methods.allowance(selectedAccount, mainContractAddr).call();
    if(approval1 <1){
        $(theButton).html("Approve")
    }

    else{
      $(theButton).html("Earn")
    }

}

}

function chartGo(){
/*
  sline = {
  chart: {
    height: 350,
    type: 'line',
    zoom: {
      enabled: false
    },
    toolbar: {
      show: false,
    }
  },
  dataLabels: {
    enabled: false
  },
  stroke: {
    curve: 'straight'
  },
  series: [{
    name: "Desktops",
    data: [10, 41, 35, 51, 49, 62, 69, 91, 148]
  }],
  title: {
    text: 'Product Trends by Month',
    align: 'left'
  },
  grid: {
    row: {
      colors: ['#f1f2f3', 'transparent'], // takes an array which will be repeated on columns
      opacity: 0.5
    },
  },
  xaxis: {
    categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
  }
}

chart = new ApexCharts(
  document.querySelector("#radial-char"),
  sline
);

chart.render();
*/

var radialChart = {
    chart: {
        height: 200,
        type: 'radialBar',
        toolbar: {
          show: false,
        }
    },
    plotOptions: {
        radialBar: {
            dataLabels: {
                name: {
                    fontSize: '14px',
                },
                value: {
                    fontSize: '14px',
                },
                total: {
                    show: true,
                    label: 'Total',
                    formatter: function (w) {
                        // By default this function returns the average of all series. The below is just an example to show the use of custom formatter function
                        return 249
                    }
                }
            }
        }
    },
    series: [44, 55, 67, 83],
    labels: ['FARM', 'BOND', 'Pickle', 'YFI'],
}

var chart = new ApexCharts(
    document.querySelector("#radial-chart"),
    radialChart
);

chart.render();

}

setTimeout(function(){
    chartGo()
}, 200)
