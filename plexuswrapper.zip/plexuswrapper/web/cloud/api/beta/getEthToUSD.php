<?php


extract($_REQUEST);

if(!isset($amount)){

  $amount = 1;
}

$amount = floatval($amount);

$rateRaw = file_get_contents("https://api.ethplorer.io/getTokenInfo/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2?apiKey=freekey");



$rawData = json_decode($rateRaw, true);

$rate = floatval($rawData['price']['rate']);

$resp = $amount * $rate;
$resp = round($resp, 2);

$theResp = array("status"=>"success", "data"=>$resp);

echo(json_encode($theResp));

?>
