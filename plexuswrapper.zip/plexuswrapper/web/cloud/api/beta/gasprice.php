<?php


extract($_REQUEST);


$rateRaw = file_get_contents("https://www.gasnow.org/api/v3/gas/price?utm_source=:PEX");



$gweis = json_decode($rateRaw, true);




$theResp = array("status"=>"success", "data"=>$gweis['data']);

echo(json_encode($theResp));

?>
