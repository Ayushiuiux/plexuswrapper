async function getTVL(){
  var tContract = new web3.eth.Contract(mainContractABI, mainContractAddr);

  var result = await  tContract.methods.getTotalValueLockedAggregated().call();
 //  console.log(result)

 var result1 = (result/100).toFixed(2);

 if(alreadyTVLCount == true){
   //no need to resload this
   return;
 }
$('#tvl').html("$" + numberWithCommas(result1).split(',')[0] + ",<span id='tvlEnd'></span>");

setTimeout(function(){
  startCountingStaked()
},100)
}


async function getThisPrice(){
  var tContract = new web3.eth.Contract(mainContractABI, mainContractAddr);

  var result = await  tContract.methods.getThisTokenPrice().call();
 //  console.log(result)

 var result1 = (result/100).toFixed(2);
$('#plexprice').html("$" + numberWithCommas(result1));
}



async function getEpochTime(){
  var tContract = new web3.eth.Contract(mainContractABI, mainContractAddr);

  var result = await  tContract.methods.timeLeftInEpoch().call();
 //  console.log(result)

 var result1 = (result/100).toFixed(0);
$('#nextEpoch').html(numberWithCommas(result1) + " mins");
}



async function getReward(){
  var tContract = new web3.eth.Contract(mainContractABI, mainContractAddr);

  var result = await  tContract.methods.getUserCurrentReward(selectedAccount).call();
 //  console.log(result)

 var result1 = (result/100).toFixed(2);
$('#currentReward').html(numberWithCommas(result1) + " PLX");
}




async function getPotReward(){
  var tContract = new web3.eth.Contract(mainContractABI, mainContractAddr);

  var result = await  tContract.methods.getUserPotentialReward(selectedAccount).call();
 //  console.log(result)

 var result1 = (result/100).toFixed(2);
$('#potentialReward').html(numberWithCommas(result1) + " PLX");
}





async function getThisTokenBalance(){
  var aContract = new web3.eth.Contract(erc20ABI, '0x0391D2021f89DC339F60Fff84546EA23E337750f');

  var result = await  aContract.methods.balanceOf(selectedAccount).call();
 //  console.log(result)

 var result1 = (result/1000000000000000000).toFixed(3);
$('#thisTBalance').html(numberWithCommas(result1) + " PLX");
}



async function getTokenBalanceOf(tokenSym, decimals, selector1){
  var aContract = new web3.eth.Contract(erc20ABI, tokenAddrs[tokenSym]);

  var result = await  aContract.methods.balanceOf(selectedAccount).call();
 //  console.log(result)

 var result1 = (result/(Math.pow(10, decimals))).toFixed(3);
$(selector1).html(numberWithCommas(result1) + " "+tokenSym);
}





async function getStakedBalance(tokenSym, decimals, selector1){
    var tContract = new web3.eth.Contract(mainContractABI, mainContractAddr);

  var result = await  tContract.methods.getAmountStakedByUser(tokenAddrs[tokenSym], selectedAccount).call();
 //  console.log(result)

 var result1 = (result/(Math.pow(10, decimals))).toFixed(3);
$(selector1).html(numberWithCommas(result1) + " "+tokenSym);
}



async function getTheAPY(tokenSym, decimals, selector1){
    var tContract = new web3.eth.Contract(mainContractABI, mainContractAddr);

  var result = await  tContract.methods.getAPY(tokenAddrs[tokenSym]).call();
 //  console.log(result)

 var result1 = (result/(Math.pow(10, decimals))).toFixed(2);
$(selector1).html(numberWithCommas(result1) + "%");


if(tokenSym =="PLEX"){

  //  $('#avgAPY').html("48.7%")
  //$('#disAvail').html('');

startDisAvail()
}


}






addAdditionalCoins()
async function getAllContractData(){




  activateDropEffects()

  getTVL();
  getThisPrice();
//  getEpochTime()



  getReward()
  getThisTokenBalance()
  getPotReward()

  rightBalance = (balance / 1000000000000000000).toFixed(3);
//  newBalance = $('table tr:nth-of-type(1) td:last-child').html().replace('--', rightBalance)
  $('.ethBalance').html(rightBalance + " ETH")


  getTokenBalanceOf("DAI",18, ".daiBalance");
  getTokenBalanceOf("USDC",6, ".usdcBalance");
  getTokenBalanceOf("PLEX",18, ".plexCoinBalance");
  getTokenBalanceOf("PLEXLP",18, ".plexUniBalance");
  getTokenBalanceOf("TUSD",18, ".tusdBalance");
  getTokenBalanceOf("USDT",6, ".usdtBalance");
  getTokenBalanceOf("SUSD",18, ".susdBalance");
  getTokenBalanceOf("FARM",18, ".farmBalance");
  getTokenBalanceOf("PICKLE",18, ".pickleBalance");
  getTokenBalanceOf("CRV",18, ".crvBalance");



  getStakedBalance("ETH",18, ".ethStaked");
  getStakedBalance("DAI",18, ".daiStaked");
  getStakedBalance("USDC",6, ".usdcStaked");
  getStakedBalance("PLEX",18, ".plexStaked");
  getStakedBalance("PLEXLP",18, ".plexUniStaked");
  getStakedBalance("USDT",6, "usdtStaked");
  getStakedBalance("SUSD",18, ".susdStaked");
  getStakedBalance("TUSD",18, ".tusdStaked");
  getStakedBalance("FARM",18, ".farmStaked");
  getStakedBalance("PICKLE",18, ".pickleStaked");
    getStakedBalance("CRV",18, ".crvStaked");



  getTheAPY("ETH",1, ".ethAPY");
  getTheAPY("DAI",1, ".daiAPY");
  getTheAPY("USDC",1, ".usdcAPY");
  getTheAPY("PLEX",1, ".plexAPY");
  getTheAPY("PLEXLP",1, ".plexUniAPY");

  getTheAPY("USDT",1, ".usdtAPY");
  getTheAPY("SUSD",1, ".susdAPY");
  getTheAPY("TUSD",1, ".tusdAPY");
  getTheAPY("FARM",1, ".farmAPY");
  getTheAPY("PICKLE",1, ".pickleAPY");
  getTheAPY("CRV",1, ".crvAPY");







console.log(rightBalance)
setTimeout(function(){
  calculateAndShowAnnualReturn()
},2000)

}



function calculateAndShowAnnualReturn(){

  $('.apyData').each(function(index){
    percentageGrowth = parseFloat($(this).html())/100;
      currentToken = $($(this).parent().parent()).find('.tokenBalanceClass').html().split(" ")[1]
    currentBalance = parseFloat($($(this).parent().parent()).find('.tokenBalanceClass').html()) +.01;
    projectionG = (currentBalance + (currentBalance*percentageGrowth)).toFixed(2)
    $($(this).parent().parent()).find('.growthAnnual').html("In 1 year: "+  projectionG + " " +currentToken)
  })

}

async function withdraw(amount, whichTokenSymb){

    var tContract = new web3.eth.Contract(mainContractABI, mainContractAddr);
    whichToken = tokenAddrs[whichTokenSymb]
    amount1 = amount;
    amount1 = amount.toString()
    console.log(amount1)

    var tx = tContract.methods.withdraw(whichToken, amount1).send({

      'from': selectedAccount,

      //'gas':190000,
      //'gasPrice':gasPriceGeneratedFast,



    }, function(error, data){


      if(!error){
      showNotif("Token Withdrawal Transaction Submitted to the Blockchain!", "You will need to wait a little while for a confirmation. Once this transaction is confirmed, all of your tokens will be safe and sound back in your wallet. You can also look at your pending transactions on MetaMask to speed this up. ");
      }


      console.log(error);
      console.log(data)






    })



}

async function deposit(amount, whichTokenSymb){


  var tContract = new web3.eth.Contract(mainContractABI, mainContractAddr);
  whichToken = tokenAddrs[whichTokenSymb]
  amount1 = amount;
  amount1 = amount.toString()
  console.log(amount1)

  if(whichToken == '0x0000000000000000000000000000000000000000'){

      if(amount1 >10000000000000000){
      amount1 = amount - 10000000000000000;
        amount1 = amount1.toString()
      }
  var tx = tContract.methods.deposit(whichToken, amount1).send({

    'from': selectedAccount,

    //'gas':190000,
    //'gasPrice':gasPriceGeneratedFast,
    value:amount1


  }, function(error, data){

    console.log(error);
    console.log(data)
    if(!error){
    showNotif("Your Token Staking Transaction Has Been Submitted to the Blockchain!", "In a few moments, once there is a confirmation on the blockchain, you will begin earning. You can see the status of your staked coins and withdraw any time by clicking on the Portfolio tab. ");


    }


  })
}


else{
var aContract = new web3.eth.Contract(erc20ABI, whichToken);

  var approval1 = await  aContract.methods.allowance(selectedAccount, mainContractAddr).call();

  if(approval1>1){
    approval = true;
  }

  else{
    approval = false;
  }
  if(approval == false){



  registerWaitFor(whichToken);

var tx = aContract.methods.approve(mainContractAddr, '1000000000000000000000000000000000').send({

  'from': selectedAccount,

  //'gas':190000,
  //'gasPrice':gasPriceGeneratedFast,



}, function(error, data){


if(!error){
showNotif("Token Approval Request Submitted to the Blockchain!", "You will need to wait a little while for a confirmation. Then you will be able to stake your tokens. You can also look at your pending transactions on MetaMask to speed this up. ");
}
  console.log(error);
  console.log(data)







})

}


else{

    var tx1 = tContract.methods.deposit(whichToken, amount1).send({

      'from': selectedAccount,

      //'gas':190000,
      //'gasPrice':gasPriceGeneratedFast,



    }, function(error, data){

      if(!error){

      showNotif("Your Token Staking Transaction Has Been Submitted to the Blockchain!", "In a few moments, once there is a confirmation on the blockchain, you will begin earning. You can see the status of your staked coins and withdraw any time by clicking on the Portfolio tab. ");

    }


      console.log(error);
      console.log(data)




    })
}














}
}


waitIntervals =[];
waitIntTokens = []
currentInt = 0;
function registerWaitFor(theToken){
  waitIntervals[currentInt] = theToken;


  currentInt = currentInt +1;

}



function getTokenSym(theAddress){

  for(i in tokenAddrs){
    if(theAddress == tokenAddrs[i]){
      return i;
    }

  }

  return "NONEFOUND";
}
function startListeningForChanges(){


  cInt = setInterval(async function(){

    for(i in waitIntervals){
      var aContract = new web3.eth.Contract(erc20ABI, waitIntervals[i]);

        var approval1 = await  aContract.methods.allowance(selectedAccount, mainContractAddr).call();
        console.log(approval1);
        if(approval1 > 1){
          thisTokenSym = getTokenSym(waitIntervals[i]);
          showNotif("You can now earn!", "Approval Transaction Complete. Please click the earn button next to " +thisTokenSym);
          $('.goBut'+thisTokenSym).html('Earn')
          waitIntervals.splice(i, 1);

        }
    }
  }, 2000);


}

function showNotif(title, msg){

  swal({
     title: title,
     text: msg,
     type: 'success',
     padding: '2em'
   })
}
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}



$("html").on("click", "#stakeSection .goButton", function(event){
  theAmount = parseFloat($($(this).parent()).find('input').val())
  theSymbo = $($(this).parent().parent().parent()).find('.tokenBalanceClass').html().split(" ")[1]
  theFrshAm = theAmount * (Math.pow(10, 18));
  console.log(theFrshAm);
  console.log(theSymbo)
  deposit(theFrshAm, theSymbo );
});


$("html").on("click", "#portfolioSection .goButton", function(event){

  theAmount = parseFloat($($(this).parent()).find('input').val())
  theSymbo = $($(this).parent().parent().parent()).find('.tokenBalanceClass').html().split(" ")[1]
  theFrshAm = theAmount * (Math.pow(10, 18));
  console.log(theFrshAm);
  withdraw(theFrshAm, theSymbo );
});



$('.maxButton').on('click', function(){
var  thisMaxBalance  = parseFloat($($(this).parent().parent().parent()).find('.tokenBalanceClass').html())
$($(this).parent()).find('input').val(thisMaxBalance)

})


alreadyTVLCount = false;
alreadyDisCount = false;
function startCountingStaked(){

  if(alreadyTVLCount == false){
    alreadyTVLCount = true;
  }
  else{
    return;
  }
  var options = {
    startVal: 130703,
    duration: 100000,
  decimalPlaces: 2,
  };
  var demo =  new countUp.CountUp('tvlEnd', 990000, options);
  if (!demo.error) {
    demo.start();
  } else {
    console.error(demo.error);
  }

}


function startDisAvail(){

  if(alreadyDisCount == false){
    alreadyDisCount = true;
  }
  else{
    return;
  }

  var options = {
    startVal: 406008072,
    duration: 100000,
  decimalPlaces: 2,
  };
  var demo =  new countUp.CountUp('disAvail', 400000000, options);
  if (!demo.error) {
    demo.start();
  } else {
    console.error(demo.error);
  }

}


setTimeout(function(){
  if(typeof selectedAccount == "undefined"){
    swal({
     title: "You need to connect your wallet",
     text: "In order to use any part of this app, you need to be connected via MetaMask or another Ethereum wallet provider. No centralization here, sorry.",
     type: 'warning',
     padding: '2em'
   })
  }
}, 2000)






function addCoinRow(name, imgPath, stakesWhere, contractAddress, sectionElem){

   template =' <tr> <td class="checkbox-column"><span class="hit1"></span><span><img src="assets/icons/'+imgPath+'" class="rounded-circle profile-img" alt="avatar"></span> </td> <td>'+name.toUpperCase()+'</td> <td><span class="'+ name+'APY apyData">--%</span></td> <td> <div class="btn-group mb-4 mr-2" role="group"> <button id="btnOutline2" type="button" class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Stake <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></button> <div class="dropdown-menu" aria-labelledby="btnOutline2" style="will-change: transform;"> <a href="javascript:void(0);" class="dropdown-item"><i class="flaticon-home-fill-1 mr-1"></i>Borrow</a> <a href="javascript:void(0);" class="dropdown-item"><i class="flaticon-home-fill-1 mr-1"></i>Deposit</a> <a href="javascript:void(0);" class="dropdown-item"><i class="flaticon-gear-fill mr-1"></i>Unstake</a> </div> </div> </td> <td> <div class="btn-group mb-4 mr-2" role="group"> <button id="btnOutline1" type="button" class="btn btn-outline-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Aave + Plex <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></button> <div class="dropdown-menu" aria-labelledby="btnOutline1" style="will-change: transform;"> <a href="javascript:void(0);" class="dropdown-item defaultLocation" style="display:none"><i class="flaticon-home-fill-1 mr-1" ></i>Aave + Plex</a> <a href="javascript:void(0);" class="dropdown-item"><i class="flaticon-home-fill-1 mr-1"></i>Harvest + Plex</a> <a href="javascript:void(0);" class="dropdown-item"><i class="flaticon-home-fill-1 mr-1"></i>Pickle + Plex</a> <a href="javascript:void(0);" class="dropdown-item"><i class="flaticon-gear-fill mr-1"></i>All + Plex</a> </div> </div> </td> <td class="maxSpan2"> <span class="maxSpan"> <input type="text" class="form-control search-form-control inputYield" style="width:100px; margin-left:0px; display:inline-block; height:45px; border-top-right-radius:0px;border-bottom-right-radius:0px;" placeholder="0"><button class="btn btn-outline-warning maxButton" style="margin-bottom:5px; display:inline-block; height:45px; margin-top:1px; border-top-left-radius:0px;border-bottom-left-radius:0px;">Max</button> </span> </td> <td class="text-center"> <span class="'+name+'Balance tokenBalanceClass">-- '+name.toUpperCase()+'</span> <br> <span style="color:#8dbf42; font-weight:bold" class="growthAnnual"></span> </td> </tr>';

   $(sectionElem +" tbody").append(template)

}



function addAdditionalCoins(){

  addCoinRow("usdt", "usdt.png", [], '0x0', '#stakeSection');
  addCoinRow("susd", "susd.png", [], '0x0', '#stakeSection');
  addCoinRow("tusd", "tusd.png", [], '0x0', '#stakeSection');
  addCoinRow("farm", "farm.png", [], '0x0', '#stakeSection');
  addCoinRow("pickle", "pickle.png", [], '0x0', '#stakeSection');
  addCoinRow("crv", "crv.png", [], '0x0', '#stakeSection');

}
